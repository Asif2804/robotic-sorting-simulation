//Needle in a Haystack
#include <stdio.h>
#include <math.h>
#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/camera.h>
#include <webots/position_sensor.h>
#include <webots/distance_sensor.h>
#include <webots/camera_recognition_object.h>

#define TIME_STEP 32
#define EPSILON 0.01
#define GRIPPER_MIN_POSITION 0.0495
#define GRIPPER_MAX_POSITION 0.85  

//Case states
enum State { WAIT, GRAB, ROTATE, DROP, RETURN };

//Gripper position limits
void safeSetGripperPosition(WbDeviceTag motor, double position) {
  if (position < GRIPPER_MIN_POSITION)
    position = GRIPPER_MIN_POSITION;
  else if (position > GRIPPER_MAX_POSITION)
    position = GRIPPER_MAX_POSITION;
  
  wb_motor_set_position(motor, position);
}

int main(int argc, char **argv) {
  wb_robot_init(); 

  int counter = 0, i = 0;
  int state = WAIT;

  //Default Arm position 
  const double initialPositions[] = {-0.62, 1.57, -1.00, 0.0};    

  double speed = 1.5;
  if (argc == 2)
    sscanf(argv[1], "%lf", &speed); 
    
  //Arm motors 
  WbDeviceTag urMotors[4];
  urMotors[0] = wb_robot_get_device("shoulder_lift_joint");
  urMotors[1] = wb_robot_get_device("elbow_joint");
  urMotors[2] = wb_robot_get_device("wrist_1_joint");
  urMotors[3] = wb_robot_get_device("wrist_2_joint");

  //Gripper motors 
  WbDeviceTag handMotors[3];
  handMotors[0] = wb_robot_get_device("finger_1_joint_1");
  handMotors[1] = wb_robot_get_device("finger_2_joint_1");
  handMotors[2] = wb_robot_get_device("finger_middle_joint_1");

  //Open gripper at start
  for (i = 0; i < 3; ++i)
    safeSetGripperPosition(handMotors[i], GRIPPER_MIN_POSITION);  

  //Position sensors for each joint
  WbDeviceTag urSensors[4];
  for (i = 0; i < 4; ++i) {
    urSensors[i] = wb_motor_get_position_sensor(urMotors[i]);
    wb_position_sensor_enable(urSensors[i], TIME_STEP); 
    wb_motor_set_velocity(urMotors[i], speed); //Motor speed
    wb_motor_set_control_pid(urMotors[i], 5.0, 0.0, 0.0);
  }

  //Camera
  WbDeviceTag camera = wb_robot_get_device("camera");
  wb_camera_enable(camera, 2 * TIME_STEP); 
  wb_camera_recognition_enable(camera, 2 * TIME_STEP); //Object recognition

  double r = 0.0, g = 0.0, b = 0.0; // RGB values for objects

  //Distance sensor
  WbDeviceTag distanceSensor = wb_robot_get_device("distance sensor");
  wb_distance_sensor_enable(distanceSensor, TIME_STEP); // Enable distance sensor

  printf("Moving to initial position...\n");
  for (i = 0; i < 4; ++i)
    wb_motor_set_position(urMotors[i], initialPositions[i]);

  //Arm ready when it reaches the initial position
  int timeout = 100;
  while (wb_robot_step(TIME_STEP) != -1 && timeout-- > 0) {
    int ready = 1;
    for (i = 0; i < 4; ++i) {
      if (fabs(wb_position_sensor_get_value(urSensors[i]) - initialPositions[i]) > 0.1) {
        ready = 0;
        break;
      }
    }
    if (ready) break;
  }
  printf("Initial position reached\n");

  //Main 
  while (wb_robot_step(TIME_STEP) != -1) {
    int numberOfObjects = wb_camera_recognition_get_number_of_objects(camera); // Get number of objects detected

    const WbCameraRecognitionObject *objects = wb_camera_recognition_get_objects(camera);
    for (i = 0; i < numberOfObjects; ++i) {
      for (int j = 0; j < objects[i].number_of_colors; ++j) {
        r = objects[i].colors[3 * j];   // Get RGB color values
        g = objects[i].colors[3 * j + 1];
        b = objects[i].colors[3 * j + 2];
        printf("Color : %lf %lf %lf\n", objects[i].colors[3 * j],
                     objects[i].colors[3 * j + 1], objects[i].colors[3 * j + 2]);
    }
    }
    //Color range for object is green or pink
    int isGreen = (r > 0.6 && r < 0.8) && (g > 0.9 && g <= 1.0) && (b > 0.4 && b < 0.6);
    int isPink  = (r > 0.9 && r <= 1.0) && (g > 0.5 && g < 0.7) && (b > 0.7 && b < 0.9);
    
    //Keep sorting until the odd one is found
    if (counter <= 0) {
      switch (state) {
        case WAIT:
          printf("WAITING\n");
          if (wb_distance_sensor_get_value(distanceSensor)< 400) { //object is detected within range
            state = GRAB;
            counter = 8;  
            printf("Grabbing object\n");
            for (i = 0; i < 3; ++i)
              safeSetGripperPosition(handMotors[i], GRIPPER_MAX_POSITION); // Close gripper
          }
          break;

        case GRAB:
          printf("OBJECT IN HANDS\n");
          if (isGreen) {
            wb_motor_set_position(urMotors[0], -2.75);  // shoulder_lift_joint
            wb_motor_set_position(urMotors[1], -2.14);  // elbow_joint
            wb_motor_set_position(urMotors[2], -2.50);  // wrist_1_joint
            wb_motor_set_position(urMotors[3], 1.50); // wrist_2_joint
            printf("Is green\n");
          }
          else if (isPink) {
             wb_motor_set_position(urMotors[0], -2.55); 
             wb_motor_set_position(urMotors[1], -2.14);  
             wb_motor_set_position(urMotors[2], -2.36); 
             wb_motor_set_position(urMotors[3], 2.31); 
             printf("Is pink\n");
          } 
          else {
            wb_motor_set_position(urMotors[0], -1.54);  
            wb_motor_set_position(urMotors[1], -1.54);  
            wb_motor_set_position(urMotors[2], 2.38); 
            wb_motor_set_position(urMotors[3], 1.51);
            printf("Found it\n");
            break;
          }
          
          state = ROTATE; 
          printf("Rotating arm\n");
          break;
          
        case ROTATE:
          if (wb_position_sensor_get_value(urSensors[2]) < -2.30) {
            counter = 8;
            printf("Dropping object\n");
            state = DROP; 
            for (i = 0; i < 3; ++i)
              safeSetGripperPosition(handMotors[i], GRIPPER_MIN_POSITION);
          }
          break;

        case DROP:
         if (wb_position_sensor_get_value(urSensors[2]) < -2.3) {
            counter = 8;
            state = RETURN; 
            printf("Moving back to initial position\n");
            for (i = 0; i < 4; ++i)
              wb_motor_set_position(urMotors[i], initialPositions[i]);
          }
          break;
         
        case RETURN:
          printf("In ROTATING_BACK. Current wrist position: %f\n", wb_position_sensor_get_value(urSensors[2]));
            if (wb_position_sensor_get_value(urSensors[2]) > -1.1) { 
               state = WAIT; 
               counter = 1; 
               printf("Returned to WAITING state.\n");
             }
             break;
      }
    }
    counter--; 
  }

  wb_robot_cleanup();
  return 0;
}
